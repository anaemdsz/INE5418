# Trab 2

## Como executar a aplicação
 - Para executar o servidor, basta utilizar o comando `bash ./server.sh`
 - Para iniciar um cliente basta utilizar o comando `bash ./run.sh`
 
 Ao iniciar um cliente você será apresentado com cinco opções sendo elas:
   - Sair
   - Escrever
   - Ler
   - Apagar
   - Aleatório